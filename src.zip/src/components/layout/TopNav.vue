<template>
  <div id="topNav" class="z-50 absolute top-0 left-0 right-0 h-8 flex items-center px-4 bg-[#F8FAFC] dark:bg-dark-900 transition-all duration-300" data-tauri-drag-region="">
    <!-- 菜单栏项目 -->
    <div class="flex items-center gap-6" data-tauri-drag-region>
      <!-- Mac风格窗口控制按钮 -->
       <div class="flex gap-2.5 mr-4">
          <button class="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 transition-colors duration-200" title="关闭" @click="handleClose"></button>
          <button class="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-600 transition-colors duration-200" title="最小化" @click="handleMinimize"></button>
          <button class="w-3 h-3 rounded-full bg-green-500 hover:bg-green-600 transition-colors duration-200" title="最大化" @click="handleMaximize"></button>
        </div>
      <!-- NeoVAI标题已删除 -->
    </div>

    <!-- 中间：占位，确保右侧元素靠右 -->
    <div class="flex-1"></div>
    
    <!-- 应用控制按钮 -->
      <div class="flex items-center gap-4">
        <!-- 新增按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="返回对话" @click="handleBackToChat">
          <i class="fa-solid fa-comments text-sm"></i>
        </button>
        
        <!-- RAG工具按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="RAG工具" @click="handleRagTool">
          <i class="fa-solid fa-database text-sm"></i>
        </button>
        
        <!-- MCP服务按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="MCP服务" @click="handleMcpService">
          <i class="fa-solid fa-server text-sm"></i>
        </button>
        
        <!-- 编译器工具按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="编译器工具" @click="handleCompilerTool">
          <i class="fa-solid fa-code text-sm"></i>
        </button>
        
        <!-- 分隔栏 -->
        <div class="h-4 w-px bg-gray-200 dark:bg-dark-700 mx-1"></div>
        
        <!-- 命令行窗口按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="命令行窗口" @click="handleCliCommand">
          <i class="fa-solid fa-terminal text-sm"></i>
        </button>
        
        <!-- 模型参数按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="模型参数" @click="handleModelParamsClick">
          <i class="fa-solid fa-sliders text-sm"></i>
        </button>
        
        <!-- 分隔栏 -->
        <div class="h-4 w-px bg-gray-200 dark:bg-dark-700 mx-1"></div>
        
        <!-- 插件按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="插件">
          <i class="fa-solid fa-puzzle-piece text-sm"></i>
        </button>
        
        <!-- 分隔栏 -->
        <div class="h-4 w-px bg-gray-200 dark:bg-dark-700 mx-1"></div>
        
        <!-- 视图切换滑块 -->
        <div class="toggle-wrapper transition-all duration-300" 
          :class="{ 'is-active': chatStore.activeView === 'grid' }"
          @click="toggleView"
          :aria-label="`切换到${chatStore.activeView === 'grid' ? '对话' : '图谱'}视图`"
          style="width: 48px; height: 24px; display: flex; align-items: center; justify-content: center;">
          <div class="toggle-slider" :class="{ 'is-active': chatStore.activeView === 'grid' }" style="width: 20px; height: 20px;"></div>
          <span class="toggle-label grid-label" style="width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">
              <i class="fa-solid fa-project-diagram text-sm"></i>
            </span>
            <span class="toggle-label list-label" style="width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">
              <i class="fa-solid fa-comments text-sm"></i>
          </span>
        </div>
        
        <!-- 主题切换按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="切换主题" @click="handleToggleTheme">
          <i :class="['fa-regular', settingsStore.systemSettings.darkMode ? 'fa-sun' : 'fa-moon', 'text-sm']"></i>
        </button>
        
        <!-- 系统设置和视图按钮 -->
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="视图" @click="toggleViewPanel">
          <i class="fa-solid fa-columns text-sm"></i>
        </button>
        <button class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300" title="系统设置" @click="handleSystemSettingsClick">
          <i class="fa-solid fa-gear text-sm"></i>
        </button>
        
        <!-- 用户按钮带下拉菜单 -->
        <div class="relative hover-scale">
          <button 
            class="btn-secondary w-4 h-4 p-0 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full text-neutral dark:text-gray-300 transition-all duration-300"
            title="用户"
            @click.stop="toggleUserMenu"
          >
            <i class="fa-solid fa-user-circle text-base" @click.stop="toggleUserMenu"></i>
          </button>
          
          <!-- 用户功能下拉菜单 -->
          <div 
            v-if="showUserMenu"
            class="absolute top-full mt-2 right-0 w-16 rounded-lg shadow-lg border z-50 dropdown-content flex flex-col items-center py-2 bg-white border-gray-200 dark:bg-dark-800 dark:border-dark-700"
          >
            <button 
              class="w-10 h-10 rounded-full flex items-center justify-center transition-colors hover:bg-gray-100 text-gray-500 dark:hover:bg-dark-700 dark:text-gray-300"
              @click="handleSwitchAccount"
              title="切换账户"
            >
              <i class="fa-solid fa-exchange"></i>
            </button>
            <div class="my-1 w-8 border-t border-gray-200 dark:border-dark-700"></div>
            <button 
              class="w-10 h-10 rounded-full flex items-center justify-center transition-colors text-red-500"
              @click="handleLogout"
              title="退出账号"
            >
              <i class="fa-solid fa-right-from-bracket"></i>
            </button>
          </div>
        </div>
      
    </div>
  </div>
  <!-- 命令行窗口组件 -->
  <CommandLine 
    :visible="showCommandLine" 
    @close="closeCommandLine"
  />
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { useSettingsStore } from '../../store/settingsStore.js';
import { useChatStore } from '../../store/chatStore.js';
import { Window } from '@tauri-apps/api/window';
import CommandLine from '../../components/common/CommandLine.vue';

// 使用全局store管理视图状态
const chatStore = useChatStore();

// 切换视图模式
const toggleView = () => {
  chatStore.activeView = chatStore.activeView === 'grid' ? 'list' : 'grid';
};


const settingsStore = useSettingsStore();
const appWindow = new Window('main');

// 用户菜单状态
const showUserMenu = ref(false);

// 命令行窗口状态
const showCommandLine = ref(false);

// 处理窗口控制按钮点击事件
const handleMinimize = () => {
  appWindow.minimize();
};

const handleMaximize = () => {
  appWindow.toggleMaximize();
};

const handleClose = () => {
  appWindow.close();
};

// 处理视图按钮点击事件 - 切换右侧面板
const toggleViewPanel = () => {
  settingsStore.toggleRightPanel();
};

// 处理系统设置按钮点击事件
const handleSystemSettingsClick = () => {
  settingsStore.setActivePanel('settings');
  
  // 直接更新activeContent状态以显示SettingsContent
  if (window.setActiveContent) {
    window.setActiveContent('settings');
  }
};

// 切换主题
const handleToggleTheme = () => {
  settingsStore.toggleDarkMode();
};

// 处理模型参数按钮点击事件
const handleModelParamsClick = () => {
  settingsStore.setActivePanel('modelParams');
};

// 切换用户菜单显示状态
const toggleUserMenu = () => {
  showUserMenu.value = !showUserMenu.value;
};

// 处理切换账户点击
const handleSwitchAccount = () => {
  showUserMenu.value = false;
  console.log('切换账户');
};

// 处理退出账号点击
const handleLogout = () => {
  showUserMenu.value = false;
  alert('退出账号功能待实现');
};

// 处理命令行窗口点击
const handleCliCommand = () => {
  showCommandLine.value = true;
};

// 关闭命令行窗口
const closeCommandLine = () => {
  showCommandLine.value = false;
};

// 处理RAG工具点击事件
const handleRagTool = () => {
  settingsStore.setActivePanel('rag');
};

// 处理MCP服务点击事件
const handleMcpService = () => {
  settingsStore.setActivePanel('mcp');
};

// 处理编译器工具点击事件
const handleCompilerTool = () => {
  settingsStore.setActivePanel('compiler');
  
  // 直接更新activeContent状态以显示CodeEditorContent
  if (window.setActiveContent) {
    window.setActiveContent('codeEditor');
  }
};

// 处理返回对话点击事件
const handleBackToChat = () => {
  // 切回左侧面板为历史会话
  settingsStore.setActivePanel('history');
  
  // 主显示区为对话页面
  if (window.setActiveContent) {
    window.setActiveContent('chat');
  }
};

// 点击外部区域关闭菜单
const closeUserMenuOnClickOutside = (event) => {
  const menuElement = document.querySelector('.dropdown-content');
  const userButtonElement = document.querySelector('.relative.hover-scale');
  
  if (menuElement && userButtonElement && !userButtonElement.contains(event.target)) {
    showUserMenu.value = false;
  }
};

// 添加点击外部事件监听
onMounted(() => {
  document.addEventListener('click', closeUserMenuOnClickOutside);
});

// 移除事件监听
onUnmounted(() => {
  document.removeEventListener('click', closeUserMenuOnClickOutside);
});
</script>

<style scoped>

/* 视图切换滑块样式 */
.toggle-wrapper {
  position: relative;
  display: inline-flex;
  align-items: center;
  background-color: #f0f2f5;
  border-radius: 12px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  user-select: none;
}

.toggle-wrapper:hover {
  background-color: #e4e6eb;
}

.toggle-wrapper.is-active {
  background-color: #f0f2f5;
}

.toggle-slider {
  position: absolute;
  top: 2px;
  left: 2px;
  background-color: #fff;
  border-radius: 50%;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.toggle-slider.is-active {
    transform: translateX(24px);
  }

.toggle-label {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #65676b;
  transition: color 0.3s ease;
}

.toggle-wrapper.is-active .list-label {
  color: #fff;
}

.toggle-wrapper:not(.is-active) .grid-label {
  color: #fff;
}

.toggle-wrapper.is-active .grid-label {
  color: #65676b;
}

.toggle-wrapper:not(.is-active) .list-label {
  color: #65676b;
}

/* 动画效果增强 */
.toggle-wrapper:active .toggle-slider {
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* 适配暗色模式 */
  .dark .toggle-wrapper {
    background-color: #3a3b3c;
  }
  
  .dark .toggle-wrapper:hover {
    background-color: #4a4b4c;
  }
  
  .dark .toggle-wrapper.is-active {
    background-color: #3a3b3c;
  }
  
  .dark .toggle-label {
    color: #b0b3b8;
  }
  
  .dark .toggle-wrapper.is-active .list-label,
  .dark .toggle-wrapper:not(.is-active) .grid-label {
    color: #fff;
  }
  
  .dark .toggle-wrapper.is-active .grid-label,
  .dark .toggle-wrapper:not(.is-active) .list-label {
    color: #b0b3b8;
  }

/* 下拉菜单动画 */
.dropdown-content {
  animation: fadeInDown 0.2s ease-out;
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 确保圆形按钮中的图标居中 */
.dropdown-content button i {
  display: flex;
  justify-content: center;
}
</style>
