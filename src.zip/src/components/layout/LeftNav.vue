<template>
  <!-- leftNav div 已删除 -->
</template>

<script setup>
// 所有功能已移至顶部导航栏
</script>

<style scoped>
/* 组件不再需要样式 */
</style>
