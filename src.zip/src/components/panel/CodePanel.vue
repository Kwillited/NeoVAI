<template>
  <div id="codePanel" class="h-full flex flex-col">
    <PanelHeader title="资源管理器" :showBackButton="false">
      <template #actions>
      </template>
    </PanelHeader>
    
    <!-- 工具栏 -->
    <div class="toolbar flex justify-center items-center p-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-100 dark:border-gray-700">
      <div class="flex items-center gap-2">
        <ActionButton
          icon="fa-file-circle-plus"
          title="新建文件"
          @click="handleNewFile"
        />
        <ActionButton
          icon="fa-folder-plus"
          title="新建文件夹"
          @click="handleNewFolder"
        />
        <ActionButton
          icon="fa-arrow-up-from-bracket"
          title="上传文件"
          @click="handleUploadFile"
        />
        <ActionButton
          icon="fa-folder-open"
          title="选择文件"
          @click="handleSelectFile"
        />

      </div>
    </div>

    <!-- 文件树内容 -->
    <div class="overflow-y-auto h-[calc(100%-75px)] scrollbar-thin">
      <div class="p-3">
        <!-- 使用 VTree 组件 -->
        <VTree 
          v-if="treeData.length > 0" 
          :data="treeData" 
          :title-field="'name'" 
          :key-field="'id'" 
          :default-expand-all="false"
          :selectable="true"
          :checkable="false"
          :node-indent="16"
          @select-change="handleNodeSelect"
          @expand-change="handleNodeExpand"
        />
        
        <!-- 空状态 -->
        <div v-else class="empty-state py-8 text-center text-gray-500 dark:text-gray-400">
          <i class="fa-solid fa-folder-tree text-3xl mb-2"></i>
          <p class="text-sm">暂无文件树数据</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { open } from '@tauri-apps/plugin-dialog';
import { readDir, BaseDirectory } from '@tauri-apps/plugin-fs';
import PanelHeader from '../common/PanelHeader.vue';
import ActionButton from '../common/ActionButton.vue';
import VTree from '@idcpj/vue-tree';
import '@idcpj/vue-tree/style.css';

// 文件树数据
const treeData = ref([]);



// 新建文件
const handleNewFile = () => {
  console.log('新建文件');
  // 这里可以添加新建文件的逻辑
};

// 新建文件夹
const handleNewFolder = () => {
  console.log('新建文件夹');
  // 这里可以添加新建文件夹的逻辑
};

// 上传文件
const handleUploadFile = () => {
  console.log('上传文件');
  // 这里可以添加上传文件的逻辑
};



// 节点选择事件
const handleNodeSelect = (node) => {
  console.log('选中的节点:', node);
  // 这里可以添加节点选择后的逻辑，如打开文件等
};

// 节点展开事件
const handleNodeExpand = (node) => {
  console.log('展开/折叠的节点:', node);
  // 这里可以添加节点展开/折叠后的逻辑，如异步加载子节点等
};

// 递归遍历文件夹函数
const traverseDirectory = async (dirPath, parentPath = '') => {
  try {
    // 读取目录内容
    const entries = await readDir(dirPath, {
      recursive: false // 非递归读取，我们自己处理递归
    });
    
    // 处理每个条目
    const children = [];
    for (const entry of entries) {
      const fullPath = `${dirPath}/${entry.name}`;
      const item = {
        id: Date.now() + Math.random(),
        name: entry.name,
        type: entry.isDir ? 'directory' : 'file',
        path: fullPath,
        expanded: false
      };
      
      // 如果是目录，递归遍历
      if (entry.isDir) {
        item.children = await traverseDirectory(fullPath, fullPath);
      }
      
      children.push(item);
    }
    
    return children;
  } catch (error) {
    console.error(`遍历目录失败: ${dirPath}`, error);
    return [];
  }
};

// 选择文件
const handleSelectFile = async () => {
  // 打开文件夹选择对话框
  const selectedFolder = await open({
    directory: true, // 选择目录
    multiple: false, // 单选
    title: '请选择项目根目录'
  });

  if (selectedFolder) {
    console.log('选择的文件夹路径：', selectedFolder);
    
    // 遍历选择的文件夹
    const children = await traverseDirectory(selectedFolder);
    
    // 更新treeData数据，触发文件树显示变化
    treeData.value = [
      {
        id: Date.now(),
        name: selectedFolder.split('\\').pop() || selectedFolder, // 获取文件夹名称
        type: 'directory',
        path: selectedFolder,
        expanded: true,
        children: children
      }
    ];
  }
};

// 初始化文件树
const initializeFileTree = () => {
  // 模拟文件树数据
  treeData.value = [
    {
      id: Date.now(),
      name: '项目根目录',
      type: 'directory',
      path: '/',
      expanded: true,
      children: [
        {
          id: Date.now() + 1,
          name: 'src',
          type: 'directory',
          path: '/src',
          expanded: false,
          children: []
        },
        {
          id: Date.now() + 2,
          name: 'public',
          type: 'directory',
          path: '/public',
          expanded: false,
          children: []
        },
        {
          id: Date.now() + 3,
          name: 'src-tauri',
          type: 'directory',
          path: '/src-tauri',
          expanded: false,
          children: []
        },
        {
          id: Date.now() + 4,
          name: 'package.json',
          type: 'file',
          path: '/package.json'
        },
        {
          id: Date.now() + 5,
          name: 'README.md',
          type: 'file',
          path: '/README.md'
        },
        {
          id: Date.now() + 6,
          name: 'vite.config.js',
          type: 'file',
          path: '/vite.config.js'
        }
      ]
    }
  ];
};

// 组件挂载时初始化文件树
onMounted(() => {
  initializeFileTree();
});
</script>

<style scoped>
/* 组件样式保持与其他面板一致 */
#codePanel {
  background-color: #ffffff;
  color: #1f2937;
}

.dark #codePanel {
  background-color: #111827;
  color: #e5e7eb;
}

/* 移除不再使用的样式 */

.file-tree-node {
  user-select: none;
}
/* 图标样式 */
.file-tree-node .fa-solid.fa-folder {
  color: #f59e0b;
}

.file-tree-node .fa-solid.fa-folder-open {
  color: #f59e0b;
}

.file-tree-node .fa-solid.fa-file {
  color: #6b7280;
}

.empty-state {
  color: #9ca3af;
}
</style>