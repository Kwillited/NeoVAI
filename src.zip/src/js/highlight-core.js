// 从node_modules中导入highlight.js的核心模块
import HighlightJS from 'highlight.js/lib/core';
export { HighlightJS };
export default HighlightJS;
