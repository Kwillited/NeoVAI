<template>
  <div class="files-list mt-3">
    <h3 class="text-sm font-medium text-gray-700 mb-2 px-2">{{ currentFolder.name }} 中的文件 ({{ currentFiles.length }})</h3>
    
    <!-- 上传文件按钮 -->
    <ActionButton
      class="btn-secondary w-full py-2 mb-3 flex items-center justify-center text-sm text-neutral hover:text-primary hover:bg-primary/10 rounded-lg transition-all duration-300"
      title="上传文件到当前知识库"
      @click="handleUploadToFolder"
      icon="fa-upload"
      style="justify-content: center;"
    >
      上传文件
    </ActionButton>
    
    <!-- 文件列表 -->
    <div v-if="currentFiles.length > 0">
      <div v-for="file in currentFiles" :key="file.path"
        class="file-item bg-white border border-gray-200 dark:bg-dark-700 rounded-lg p-3 mb-2 hover:bg-gray-50 transition-all duration-300"
      >
        <div class="file-header flex items-center justify-between">
          <div class="flex items-center">
            <i class="fa-solid fa-file text-gray-600 mr-2"></i>
            <span class="font-medium text-sm text-gray-800">{{ file.name }}</span>
          </div>
          <span class="text-xs text-gray-500">{{ formatFileSize(file.size) }}</span>
        </div>
        <div class="file-meta text-xs text-gray-500 mt-1">
          {{ file.created_at ? new Date(file.created_at).toLocaleDateString() : '未知时间' }}
        </div>
      </div>
    </div>
    
    <!-- 空文件状态 -->
    <StateDisplay v-else-if="!loadingFiles" type="empty" title="暂无文件" message="该知识库中暂无文件，点击上方'上传文件'按钮添加" icon="fa-file-circle-exclamation" />
    
    <!-- 加载文件状态 -->
    <StateDisplay v-if="loadingFiles" type="loading" message="加载文件中..." />
  </div>
</template>

<script setup>
import ActionButton from '../common/ActionButton.vue';
import StateDisplay from '../common/StateDisplay.vue';

const props = defineProps({
  currentFolder: {
    type: Object,
    required: true
  },
  currentFiles: {
    type: Array,
    default: () => []
  },
  loadingFiles: {
    type: Boolean,
    default: false
  }
});

// 格式化文件大小
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// 处理上传文件到当前文件夹
const handleUploadToFolder = () => {
  const event = new CustomEvent('uploadToFolder', {
    detail: props.currentFolder
  });
  window.dispatchEvent(event);
};
</script>

<style scoped>
/* 文件列表样式 */
.files-list {
  margin-top: 12px;
}

.files-list h3 {
  font-size: 13px;
  font-weight: 500;
  color: #4b5563;
  margin-bottom: 8px;
  padding: 0 8px;
}

.file-item {
  transition: all 0.2s ease;
}

.file-item:hover {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.file-header {
  display: flex;
  align-items: center;
  height: 28px;
  line-height: 28px;
}

/* 空状态和加载状态样式 */
.empty-state,
.loading-state {
  padding: 24px;
  text-align: center;
  color: #6b7280;
}

.empty-state i {
  font-size: 36px;
  margin-bottom: 8px;
  color: #9ca3af;
}

.empty-state p {
  font-size: 14px;
  margin: 0;
}

.empty-state p:last-child {
  font-size: 12px;
  margin-top: 4px;
  color: #9ca3af;
}

.loading-state .animate-spin {
  width: 24px;
  height: 24px;
  margin: 0 auto 8px;
}

.loading-state p {
  font-size: 13px;
  color: #6b7280;
  margin: 0;
}
</style>