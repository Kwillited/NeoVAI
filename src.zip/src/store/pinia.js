import { createPinia } from 'pinia';

// 创建Pinia实例
const pinia = createPinia();

export default pinia;
